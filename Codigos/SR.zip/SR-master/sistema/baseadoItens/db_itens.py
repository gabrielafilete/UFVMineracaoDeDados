#base de dados invertidas
avaliacoesFilme = {'Freddy x Jason':
		{'Ana': 2.5,
		 'Marcos:': 3.0 ,
		 'Pedro': 2.5,
		 'Adriano': 3.0,
		 'Janaina': 3.0 },

	 'O Ultimato Bourne':
		{'Ana': 3.5,
		 'Marcos': 3.5,
		 'Pedro': 3.0,
		 'Claudia': 3.5,
		 'Adriano': 4.0,
		 'Janaina': 4.0,
		 'Leonardo': 4.5 },

	 'Star Trek':
		{'Ana': 3.0,
		 'Marcos:': 1.5,
		 'Claudia': 3.0,
		 'Adriano': 2.0 },

	 'Exterminador do Futuro':
		{'Ana': 3.5,
		 'Marcos:': 5.0 ,
		 'Pedro': 3.5,
		 'Claudia': 4.0,
		 'Adriano': 3.0,
		 'Janaina': 5.0,
		 'Leonardo': 4.0},

	 'Norbit':
		{'Ana': 2.5,
		 'Marcos:': 3.0 ,
		 'Claudia': 2.5,
		 'Adriano': 2.0,
		 'Janaina': 3.5,
		 'Leonardo': 1.0},

	 'Star Wars':
		{'Ana': 3.0,
		 'Marcos:': 3.5,
		 'Pedro': 4.0,
		 'Claudia': 4.5,
		 'Adriano': 3.0,
		 'Janaina': 3.0}
}
